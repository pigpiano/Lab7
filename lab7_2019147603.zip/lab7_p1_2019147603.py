import re

def find_function_usage(file_path):
    # 파일 내용 읽기
    with open(file_path, 'r') as file:
        code = file.read()

    # 함수 선언 및 호출을 찾기 위한 정규 표현식
    declaration_pattern = r'def (\w+)\('
    call_pattern = r'(\w+)\('

    # 모든 선언 찾기
    declarations = re.findall(declaration_pattern, code)

    # 함수 선언 및 호출 정보를 저장할 사전
    functions = {name: {'def_line': None, 'call_lines': []} for name in declarations}

    # 코드의 각 줄을 순회
    for line_number, line in enumerate(code.split('\n'), 1):
        # 함수 선언 확인
        for match in re.finditer(declaration_pattern, line):
            func_name = match.group(1)
            functions[func_name]['def_line'] = line_number

        # 함수 호출 확인
        for match in re.finditer(call_pattern, line):
            func_name = match.group(1)
            # match.group(1)을 통해 찾은 함수 이름(func_name)이 functions 사전에 존재하는지 확인
            # 함수의 선언 줄을 호출 목록 에서 제외 하기 위한 조건
            if func_name in functions and line_number != functions[func_name]['def_line']:
                # 이미 추가된 줄 번호가 아니라면 추가
                if line_number not in functions[func_name]['call_lines']:
                    functions[func_name]['call_lines'].append(line_number)

    # 출력 형식 지정
    return "\n".join(f"{func}: def in {details['def_line']}, calls in {details['call_lines']}"
                     for func, details in functions.items())


file_path = "input_7_1.txt"

# 함수 실행 및 출력
output = find_function_usage(file_path)
print(output)
