class not2DError(Exception):
    def __str__(self):
        # 리스트가 2차원이 아님
        return '[ERROR]: list is not 2D.'

class unevenListError(Exception):
    def __str__(self):
        # 내부 리스트의 길이가 다름
        return '[ERROR]: inner lists are not same in length.'

class improperMatrixError(Exception):
    def __str__(self):
        # 행렬 곱셈이 불가능한 경우
        return '[ERROR]: [a][b]*[c][d] not b==c.'

def mul1d(arr1, arr2):
    # 1차원 배열의 곱셈 결과를 계산
    return sum(a * b for a, b in zip(arr1, arr2))

class list_D2(list):
    def __init__(self, arr):
        # 리스트가 2차원인지 확인
        if not all(isinstance(inner, list) for inner in arr):
            raise not2DError()

        # 모든 내부 리스트가 동일한 길이인지 확인
        first_length = len(arr[0])
        if not all(len(inner) == first_length for inner in arr):
            raise unevenListError()

        super().__init__(arr)


    def __str__(self):
        if not self:
            return "list_2D: 0*0"
        # 2차원 리스트의 크기를 문자열로 반환
        return f"list_2D: {len(self)}*{len(self[0])}"

    def transpose(self):
        # 2차원 리스트를 전치
        return list_D2([list(column) for column in zip(*self)])

    def __matmul__(self, other):
        # 행렬 곱셈 수행
        if len(self[0]) != len(other):
            raise improperMatrixError()
        result = [[mul1d(row, col) for col in zip(*other)] for row in self]
        return list_D2(result)

    def avg(self):
        total = sum(sum(row) for row in self)
        count = sum(len(row) for row in self)
        # 리스트의 평균값 계산
        return total / count if count > 0 else 0.0
