import re
from collections import Counter

def count_alphabet(file_path):
    with open(file_path, 'r') as file: # 파일을 안전하게 열고 자동으로 닫아준다.
        text = file.read() # 파일의 전체 내용을 문자열로 읽는다.

    alphabets = re.findall(r'[a-zA-Z]', text) # 텍스트에서 모든 영문 알파벳 문자를 찾는다.
    alphabets = [alpha.upper() for alpha in alphabets] # 모든 알파벳을 대문자로 변환

    alphabet_counts = Counter(alphabets) # 각 알파벳 문자의 출현 횟수를 계산하고, 이 정보를 딕셔너리 형태로 저장
    # print(alphabet_counts)
    # 알파벳을 출현 횟수에 따라 내림차순으로 정렬
    sorted_alphabets = sorted(alphabet_counts.items(), key=lambda x: x[1], reverse=True)
    sorted_alphabets = [alpha[0] for alpha in sorted_alphabets]

    return sorted_alphabets


file_path = "input_7_2.txt"

output = count_alphabet(file_path)
print(output)
